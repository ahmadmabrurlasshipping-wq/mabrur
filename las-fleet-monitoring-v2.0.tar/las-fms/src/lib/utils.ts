import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwindcss-merge';
import { format, formatDistanceToNow, differenceInDays } from 'date-fns';
import { id as idLocale } from 'date-fns/locale';

// Tailwind className merger
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Date formatting utilities
export function formatDate(date: string | Date | null | undefined, formatStr: string = 'dd MMM yyyy'): string {
  if (!date) return '—';
  try {
    return format(new Date(date), formatStr, { locale: idLocale });
  } catch {
    return '—';
  }
}

export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return '—';
  try {
    return format(new Date(date), 'dd MMM yyyy HH:mm', { locale: idLocale });
  } catch {
    return '—';
  }
}

export function formatRelativeTime(date: string | Date | null | undefined): string {
  if (!date) return '—';
  try {
    return formatDistanceToNow(new Date(date), { addSuffix: true, locale: idLocale });
  } catch {
    return '—';
  }
}

export function daysUntil(date: string | Date | null | undefined): number {
  if (!date) return 9999;
  try {
    return differenceInDays(new Date(date), new Date());
  } catch {
    return 9999;
  }
}

// Number formatting
export function formatNumber(value: number | null | undefined, decimals: number = 0): string {
  if (value === null || value === undefined) return '—';
  return new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

export function formatCurrency(value: number | null | undefined, currency: string = 'IDR'): string {
  if (value === null || value === undefined) return '—';
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency,
  }).format(value);
}

// Status badge helpers
export function getExpiryBadgeVariant(expiryDate: string | Date | null | undefined): 'success' | 'warning' | 'danger' | 'muted' {
  if (!expiryDate) return 'muted';
  const days = daysUntil(expiryDate);
  if (days < 0) return 'danger';
  if (days < 30) return 'danger';
  if (days < 60) return 'warning';
  return 'success';
}

export function getExpiryBadgeText(expiryDate: string | Date | null | undefined): string {
  if (!expiryDate) return '—';
  const days = daysUntil(expiryDate);
  if (days < 0) return 'Kadaluarsa';
  if (days < 9000) return `${days} hari lagi`;
  return 'Valid ✓';
}

// Vessel status helpers
export const vesselStatusConfig = {
  operational: {
    label: 'Beroperasi',
    badge: 'success',
    color: 'text-green-400',
    bgColor: 'bg-green-500/10',
  },
  docking: {
    label: 'Docking',
    badge: 'warning',
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/10',
  },
  building: {
    label: 'Building Process',
    badge: 'info',
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
  },
} as const;

// Crew status helpers
export const crewStatusConfig = {
  onboard: {
    label: 'Di Kapal',
    badge: 'success',
    color: 'text-green-400',
  },
  leave: {
    label: 'Cuti',
    badge: 'info',
    color: 'text-cyan-400',
  },
  standby: {
    label: 'Standby',
    badge: 'warning',
    color: 'text-orange-400',
  },
  medical: {
    label: 'Cuti Medis',
    badge: 'danger',
    color: 'text-red-400',
  },
} as const;

// Rotation status helpers (Fixed: Kanban → Roster)
export const rotationStatusConfig = {
  leave: {
    label: 'Cuti',
    badge: 'info',
    color: 'var(--neon)',
  },
  planned: {
    label: 'Direncanakan',
    badge: 'muted',
    color: 'var(--text-400)',
  },
  enroute: {
    label: 'En Route',
    badge: 'warning',
    color: 'var(--warning)',
  },
  onboard: {
    label: 'Di Kapal',
    badge: 'success',
    color: 'var(--success)',
  },
} as const;

// Avatar helpers
export function getInitials(name: string | null | undefined): string {
  if (!name) return '?';
  return name
    .trim()
    .split(/\s+/)
    .map((word) => word[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();
}

export function getAvatarColor(name: string | null | undefined): string {
  const colors = [
    '#0099dd',
    '#00cc88',
    '#ff6b35',
    '#cc44aa',
    '#6644cc',
    '#00aacc',
    '#ee6644',
    '#44bbaa',
  ];
  if (!name) return colors[0];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash + name.charCodeAt(i)) % colors.length;
  }
  return colors[hash];
}

// File size formatter
export function formatFileSize(bytes: number | null | undefined): string {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIndex = 0;
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  return `${size.toFixed(2)} ${units[unitIndex]}`;
}

// Generate unique ID
export function generateId(prefix: string = ''): string {
  return prefix + Date.now().toString(36) + Math.random().toString(36).substring(2);
}

// Validation helpers
export function isValidEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

export function isValidPhoneNumber(phone: string): boolean {
  const re = /^[+]?[\d\s-()]+$/;
  return re.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

// MLC compliance check
export function checkMLCCompliance(workHours: number, restHours: number): boolean {
  return restHours >= 10 && workHours <= 14;
}

// Sort functions
export function sortByDate<T>(array: T[], key: keyof T, order: 'asc' | 'desc' = 'asc'): T[] {
  return [...array].sort((a, b) => {
    const dateA = new Date(a[key] as any).getTime();
    const dateB = new Date(b[key] as any).getTime();
    return order === 'asc' ? dateA - dateB : dateB - dateA;
  });
}

export function sortByString<T>(array: T[], key: keyof T, order: 'asc' | 'desc' = 'asc'): T[] {
  return [...array].sort((a, b) => {
    const strA = String(a[key]).toLowerCase();
    const strB = String(b[key]).toLowerCase();
    if (order === 'asc') {
      return strA < strB ? -1 : strA > strB ? 1 : 0;
    } else {
      return strA > strB ? -1 : strA < strB ? 1 : 0;
    }
  });
}
